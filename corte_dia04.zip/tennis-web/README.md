# Baufest Tennis v2.0

Aplicación Baufest Tennis desarrollada para el PEI de Fullstack React/Java

### Scripts

Instalar dependencias:
```sh
npm install
```

Modo desarrollo
```sh
npm run start
```

Modo mock
```sh
npm run dev:mock
```

Traspilar app
```sh
npm run build
```

---
