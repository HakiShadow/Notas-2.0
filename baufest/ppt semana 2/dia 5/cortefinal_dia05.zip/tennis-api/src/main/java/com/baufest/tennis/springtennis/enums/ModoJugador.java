package com.baufest.tennis.springtennis.enums;

public enum ModoJugador {

	/* Definimos como enums los dos posibles "Modos"
	 * de nuestros jugadores */
	LOCAL, VISITANTE;
}
