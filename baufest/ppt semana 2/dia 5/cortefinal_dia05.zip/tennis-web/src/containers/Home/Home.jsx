import React from "react";
import Typography from "../../components/Typography/Typography";

const Home = () => {
    return(
        <>
            <Typography id={"title-id"}>Home</Typography>
        </>
    )
}

export default Home;
