import React from "react";
import Typography from "../../components/Typography/Typography";

const About = () => {
    return(
        <>
            <Typography id={"title-id"}>About</Typography>
        </>
    )
}

export default About;
