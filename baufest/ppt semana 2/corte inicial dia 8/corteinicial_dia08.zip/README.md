# PEI Full Stack - Baufest Tennis App
![Logo](https://images.unsplash.com/photo-1595057602304-8b54f16dc1b0?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80)


## FAQ

#### ¿Donde encuentro la posta de la posta?

Posiblemente [acá.](https://baufest.gitbook.io/baufest-pei/)

#### ¿De verdad me estas diciendo qué en ese link encuentro la posta?

¿Vos pensas que te voy a mentir?. Andá a hacer click allá arriba.

## Author

![badge](https://img.shields.io/static/v1.svg?style=flat-square&label=Señor%20X&message=Sr.%20Fullstack%20Developer&labelColor=1A1A1A&color=999999&logo=hackaday)
