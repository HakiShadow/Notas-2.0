package com.baufest.tennis.springtennis.enums;

public enum Estado {

	/* Definimos como enums los tres posibles "Estados"
	 * de nuestros partidos */
	EN_CURSO, NO_INICIADO, FINALIZADO;
}
